ls
ls -l
ls -la
pwd
cd
cd Documents
cd
touch file1 (filename1)
cat > file2 (filename2)
ctrl z
cat >> file2 (filename2)
ctrl z
mkdir
mkdir d1 (new directory name)
cd d1
date
cd..
cp
Em
mv
nano (Don’t panic this command will open a new screen named Buffer just type “CTRL Z” and you’ll come back to the terminal)
cd
cd home
cd Pictures
cd
gcc –version
pwd
fg (if next line is not green colored just type “CTRL Z”)
bg (if next line is not green colored just type “CTRL Z”)
ps
ps -e
kill 3675
ps -e
whoami
whoami&

